const browserEnv = require('browser-env')

browserEnv()
