class Adapter(object):
    pass

class cheatAdapter(Adapter):
    pass

